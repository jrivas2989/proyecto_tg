CREATE DATABASE IF NOT EXISTS `supportix`;

USE `supportix`;

SET foreign_key_checks = 0;

DROP TABLE IF EXISTS `category`;

CREATE TABLE `category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

INSERT INTO `category` VALUES (1,"Jose Rivas"),
(2,"Laura Villanueva"),
(3,"Angelin Lugo"),
(4,"Bryn Suarez"),
(5,"Freddy Gandica");


DROP TABLE IF EXISTS `kind`;

CREATE TABLE `kind` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

INSERT INTO `kind` VALUES (1,"Conexion"),
(2,"Velocidad"),
(3,"Router"),
(4,"Bloqueo"),
(6,"Site Caido"),
(7,"Mudanza"),
(8,"Por visita");


DROP TABLE IF EXISTS `priority`;

CREATE TABLE `priority` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO `priority` VALUES (1,"Alta"),
(2,"Media"),
(3,"Baja");


DROP TABLE IF EXISTS `project`;

CREATE TABLE `project` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) DEFAULT NULL,
  `description` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

INSERT INTO `project` VALUES (1,"Ventas","dpto ventas"),
(2,"Soporte","soporte"),
(3,"Administracion","administracion"),
(4,"Facebook","red social facebook");


DROP TABLE IF EXISTS `rol`;

CREATE TABLE `rol` (
  `idrol` int(11) NOT NULL AUTO_INCREMENT,
  `rol` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`idrol`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO `rol` VALUES (1,"Administrador"),
(2,"operador"),
(3,"usuario");


DROP TABLE IF EXISTS `site`;

CREATE TABLE `site` (
  `id` int(32) NOT NULL,
  `name` varchar(200) CHARACTER SET latin1 DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

INSERT INTO `site` VALUES (1,"Agueybana"),
(2,"Acqualina"),
(3,"Arallanes"),
(4,"Monte Flores"),
(5,"Cedro"),
(6,"Bello Horizonte"),
(7,"Lagos del Norte"),
(8,"Palma sola");


DROP TABLE IF EXISTS `status`;

CREATE TABLE `status` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

INSERT INTO `status` VALUES (1,"Pendiente"),
(2,"En Desarrollo"),
(3,"Terminado"),
(4,"Cancelado");


DROP TABLE IF EXISTS `ticket`;

CREATE TABLE `ticket` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(100) DEFAULT NULL,
  `nombre_cliente` varchar(50) NOT NULL,
  `description` text,
  `updated_at` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `kind_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `asigned_id` int(11) DEFAULT NULL,
  `project_id` int(11) DEFAULT NULL,
  `site_id` varchar(100) CHARACTER SET utf8 COLLATE utf8_swedish_ci NOT NULL,
  `category_id` int(11) DEFAULT NULL,
  `priority_id` int(11) NOT NULL DEFAULT '1',
  `status_id` int(11) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `priority_id` (`priority_id`),
  KEY `status_id` (`status_id`),
  KEY `user_id` (`user_id`),
  KEY `kind_id` (`kind_id`),
  KEY `category_id` (`category_id`),
  KEY `project_id` (`project_id`),
  CONSTRAINT `ticket_ibfk_1` FOREIGN KEY (`priority_id`) REFERENCES `priority` (`id`),
  CONSTRAINT `ticket_ibfk_2` FOREIGN KEY (`status_id`) REFERENCES `status` (`id`),
  CONSTRAINT `ticket_ibfk_3` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`),
  CONSTRAINT `ticket_ibfk_4` FOREIGN KEY (`kind_id`) REFERENCES `kind` (`id`),
  CONSTRAINT `ticket_ibfk_5` FOREIGN KEY (`category_id`) REFERENCES `category` (`id`),
  CONSTRAINT `ticket_ibfk_6` FOREIGN KEY (`project_id`) REFERENCES `project` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=latin1;

INSERT INTO `ticket` VALUES (16,"Problemas en su play","Rafael Lopez","no puedo acceder a la red","2020-02-11 17:27:09","2020-01-05 21:49:13",4,2,NULL,2,5,1,1,3),
(18,"Problemas en su play","Roberto Rosario","solo le llegan 2mb","2020-02-11 17:26:52","2020-01-05 22:17:35",2,2,NULL,2,5,1,2,3),
(19,"Lentitud en el servicio","Wilmer Leal","no toma clave wifi","2020-02-11 18:05:59","2020-01-16 22:12:37",3,1,NULL,1,6,1,2,1),
(20,"Quiere mudarse","Melvin Black","Cliente requiere mudanza a nueva ubicacion",NULL,"2020-02-05 22:53:19",7,1,NULL,2,5,4,1,1),
(21,"test1","Adriana Gonzalez","Esta sin conexion","2020-02-11 18:05:31","2020-02-05 23:28:28",1,1,NULL,2,6,3,1,1),
(29,"No le funciona","Usuario","sdfsd",NULL,"2020-02-09 14:47:37",3,1,NULL,1,2,1,1,2),
(30,"test1","Esteban","No logra acceder a su consola de play","2020-02-11 18:06:12","2020-02-09 15:31:05",4,1,NULL,2,6,1,1,1),
(31,"Antena no conecta","Carlos acosta","sospecha desconfiguracion","2020-02-11 18:12:29","2020-02-11 18:07:57",1,1,NULL,1,7,1,1,2);


DROP TABLE IF EXISTS `user`;

CREATE TABLE `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) DEFAULT NULL,
  `name` varchar(50) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `password` varchar(60) DEFAULT NULL,
  `profile_pic` varchar(250) DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `kind` int(11) NOT NULL DEFAULT '1',
  `created_at` datetime DEFAULT NULL,
  `idprofile` int(11) NOT NULL,
  `rol` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;

INSERT INTO `user` VALUES (1,"admin","Administrador","administrador@gmail.com","90b9aa7e25f80cf4f64e990b78a9fc5ebd6cecad","foto1.jpg",1,1,"2017-07-15 12:05:45",1,1),
(2,"operador","Jose Rivas Hernandez","joseanriher@gmail.com","fe703d258c7ef5f50b71e06565a65aa07194907f","foto1.jpg",1,2,"2019-11-08 02:36:30",2,2),
(7,NULL,"Carlos Mujica","usuario prueba","adcd7048512e64b48da55b027577886ee5a36350","foto1.jpg",1,1,"2020-02-03 03:37:59",0,0),
(9,NULL,"ABC ABC","deprueba","adcd7048512e64b48da55b027577886ee5a36350","foto1.jpg",1,1,"2020-02-06 03:52:00",0,0);


SET foreign_key_checks = 1;
